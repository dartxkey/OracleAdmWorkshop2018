#!/bin/sh

OLD_UMASK=`umask`
umask 0027
mkdir -p /home/oracle/app/oracle/admin/belo/adump
mkdir -p /home/oracle/app/oracle/admin/belo/dpdump
mkdir -p /home/oracle/app/oracle/admin/belo/pfile
mkdir -p /home/oracle/app/oracle/cfgtoollogs/dbca/belo
mkdir -p /home/oracle/app/oracle/flash_recovery_area/belo
mkdir -p /home/oracle/app/oracle/flash_recovery_area/belo/belo
mkdir -p /home/oracle/app/oracle/oradata/belo
mkdir -p /home/oracle/app/oracle/product/11.2.0/dbhome_1/dbs
umask ${OLD_UMASK}
ORACLE_SID=belo; export ORACLE_SID
PATH=$ORACLE_HOME/bin:$PATH; export PATH
echo You should Add this entry in the /etc/oratab: belo:/home/oracle/app/oracle/product/11.2.0/dbhome_1:Y
/home/oracle/app/oracle/product/11.2.0/dbhome_1/bin/sqlplus /nolog @/home/oracle/app/oracle/admin/belo/scripts/belo.sql
