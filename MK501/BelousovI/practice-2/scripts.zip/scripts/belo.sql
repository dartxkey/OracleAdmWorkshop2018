set verify off
ACCEPT sysPassword CHAR PROMPT 'Enter new password for SYS: ' HIDE
ACCEPT systemPassword CHAR PROMPT 'Enter new password for SYSTEM: ' HIDE
host /home/oracle/app/oracle/product/11.2.0/dbhome_1/bin/orapwd file=/home/oracle/app/oracle/product/11.2.0/dbhome_1/dbs/orapwbelo force=y
@/home/oracle/app/oracle/admin/belo/scripts/CreateDB.sql
@/home/oracle/app/oracle/admin/belo/scripts/CreateDBFiles.sql
@/home/oracle/app/oracle/admin/belo/scripts/CreateDBCatalog.sql
@/home/oracle/app/oracle/admin/belo/scripts/JServer.sql
@/home/oracle/app/oracle/admin/belo/scripts/context.sql
@/home/oracle/app/oracle/admin/belo/scripts/xdb_protocol.sql
@/home/oracle/app/oracle/admin/belo/scripts/ordinst.sql
@/home/oracle/app/oracle/admin/belo/scripts/interMedia.sql
@/home/oracle/app/oracle/admin/belo/scripts/cwmlite.sql
@/home/oracle/app/oracle/admin/belo/scripts/spatial.sql
@/home/oracle/app/oracle/admin/belo/scripts/emRepository.sql
@/home/oracle/app/oracle/admin/belo/scripts/apex.sql
@/home/oracle/app/oracle/admin/belo/scripts/owb.sql
@/home/oracle/app/oracle/admin/belo/scripts/lockAccount.sql
@/home/oracle/app/oracle/admin/belo/scripts/postDBCreation.sql
